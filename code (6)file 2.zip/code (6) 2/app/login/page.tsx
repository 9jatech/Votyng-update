"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { motion, AnimatePresence } from "framer-motion"
import Link from "next/link"
import { useRouter } from "next/navigation"
import { createClient } from "@/lib/supabase/client"
import { useRouter } from 'next/navigation';

export default function Login() {
  const router = useRouter()
  const supabase = createClient()

  const [email, setEmail] = useState("")
  const [password, setPassword] = useState("")
  const [showPassword, setShowPassword] = useState(false)
  const [isLoading, setIsLoading] = useState(false)
  const [error, setError] = useState("")

  const [step, setStep] = useState(1) // 1: login, 2: OTP verification
  const [otpCode, setOtpCode] = useState("")
  const [otpTimer, setOtpTimer] = useState(0)
  const [showSuccess, setShowSuccess] = useState(false)
const router = useRouter();
  useEffect(() => {
    let interval: NodeJS.Timeout
    if (step === 2 && otpTimer > 0) {
      interval = setInterval(() => {
        setOtpTimer((prev) => prev - 1)
      }, 1000)
    }
    return () => clearInterval(interval)
  }, [step, otpTimer])

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!email || !password) return

    setError("")
    setIsLoading(true)

    try {
      const { data, error: signInError } = await supabase.auth.signInWithPassword({
        email,
        password,
      })

      if (signInError) {
        throw new Error(signInError.message)
      }

      if (!data.user) {
        throw new Error("Login failed")
      }

      const { error: otpError } = await supabase.auth.signInWithOtp({
        email,
        options: {
          emailRedirectTo: process.env.NEXT_PUBLIC_DEV_SUPABASE_REDIRECT_URL || `${window.location.origin}`,
        },
      })

      if (otpError) {
        console.error("[v0] OTP send error:", otpError.message)
        // Continue anyway - OTP is optional
      }

      // Move to OTP verification step
      setStep(2)
      setOtpTimer(60)
      console.log("[v0] Login successful, OTP sent to email")
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : "An error occurred. Please try again."
      setError(errorMessage)
      console.error("[v0] Login error:", errorMessage)
    } finally {
      setIsLoading(false)
    }
  }

  const handleVerifyOtp = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!otpCode) return

    setError("")
    setIsLoading(true)

    try {
      const { data, error: verifyError } = await supabase.auth.verifyOtp({
        email,
        token: otpCode,
        type: "email",
      })

      if (verifyError) {
        throw new Error(verifyError.message)
      }

      if (!data.user) {
        throw new Error("OTP verification failed")
      }

      setShowSuccess(true)
      console.log("[v0] OTP verified successfully")
await supabase.auth.getSession();
window.location.href = '/dashboard';
      
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : "Invalid OTP code"
      setError(errorMessage)
      console.error("[v0] OTP verification error:", errorMessage)
    } finally {
      setIsLoading(false)
    }
  }

  const handleResendOtp = async () => {
    setError("")
    setIsLoading(true)

    try {
      const { error: otpError } = await supabase.auth.signInWithOtp({
        email,
        options: {
          emailRedirectTo: process.env.NEXT_PUBLIC_DEV_SUPABASE_REDIRECT_URL || `${window.location.origin}`,
        },
      })

      if (otpError) {
        throw new Error(otpError.message)
      }

      setOtpTimer(60)
      console.log("[v0] OTP resent successfully")
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : "Failed to resend OTP"
      setError(errorMessage)
      console.error("[v0] Resend OTP error:", errorMessage)
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <main className="bg-black min-h-screen flex items-center justify-center px-4">
      <motion.div
        className="w-full max-w-md bg-card border border-primary/20 rounded-2xl p-8 backdrop-blur-sm"
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
      >
        {/* Header */}
        <div className="text-center mb-8">
          <h1 className="text-3xl font-bold text-primary mb-2">VOTY</h1>
          <h2 className="text-2xl font-bold text-white">{step === 1 ? "Welcome Back" : "Verify Your Email"}</h2>
          <p className="text-muted-foreground mt-2">
            {step === 1 ? "Continue your journey with us" : `We sent a code to ${email}`}
          </p>
        </div>

        <AnimatePresence mode="wait">
          {step === 1 ? (
            <motion.form
              key="login"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              onSubmit={handleLogin}
              className="space-y-6"
            >
              <div>
                <label className="block text-sm font-medium text-white mb-2">Email</label>
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="Enter your email"
                  className="w-full px-4 py-3 bg-background border border-primary/20 rounded-lg text-white placeholder-muted-foreground focus:outline-none focus:border-primary focus:ring-2 focus:ring-primary/30 transition-all"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-white mb-2">Password</label>
                <div className="relative">
                  <input
                    type={showPassword ? "text" : "password"}
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="Enter your password"
                    className="w-full px-4 py-3 bg-background border border-primary/20 rounded-lg text-white placeholder-muted-foreground focus:outline-none focus:border-primary focus:ring-2 focus:ring-primary/30 transition-all"
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute right-3 top-3 text-primary hover:text-primary/80 transition-colors text-sm font-medium"
                  >
                    {showPassword ? "Hide" : "Show"}
                  </button>
                </div>
              </div>

              {error && (
                <motion.div
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  className="p-3 bg-red-500/10 border border-red-500/30 rounded-lg text-red-500 text-sm"
                >
                  {error}
                </motion.div>
              )}

              <div className="flex justify-end">
                <Link
                  href="/forgot-password"
                  className="text-sm text-primary hover:text-primary/80 transition-colors font-medium"
                >
                  Forgot Password?
                </Link>
              </div>

              <button
                type="submit"
                disabled={!email || !password || isLoading}
                className="w-full py-3 bg-primary text-black rounded-lg font-bold hover:bg-primary/90 transition-all disabled:opacity-50 disabled:cursor-not-allowed glow-gold-hover"
              >
                {isLoading ? "Signing In..." : "Sign In"}
              </button>
            </motion.form>
          ) : (
            <motion.form
              key="otp"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              onSubmit={handleVerifyOtp}
              className="space-y-6"
            >
              <div>
                <label className="block text-sm font-medium text-white mb-2">Verification Code</label>
                <input
                  type="text"
                  value={otpCode}
                  onChange={(e) => setOtpCode(e.target.value.replace(/[^0-9]/g, "").slice(0, 6))}
                  placeholder="Enter 6-digit code"
                  maxLength={6}
                  className="w-full px-4 py-3 bg-background border border-primary/20 rounded-lg text-white placeholder-muted-foreground focus:outline-none focus:border-primary focus:ring-2 focus:ring-primary/30 transition-all text-center text-lg tracking-widest"
                />
              </div>

              {error && (
                <motion.div
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  className="p-3 bg-red-500/10 border border-red-500/30 rounded-lg text-red-500 text-sm"
                >
                  {error}
                </motion.div>
              )}

              <button
                type="submit"
                disabled={otpCode.length !== 6 || isLoading}
                className="w-full py-3 bg-primary text-black rounded-lg font-bold hover:bg-primary/90 transition-all disabled:opacity-50 disabled:cursor-not-allowed glow-gold-hover"
              >
                {isLoading ? "Verifying..." : "Verify Code"}
              </button>

              <button
                type="button"
                onClick={handleResendOtp}
                disabled={otpTimer > 0 || isLoading}
                className="w-full py-3 border border-primary text-primary rounded-lg font-bold hover:bg-primary/10 transition-all disabled:opacity-50 disabled:cursor-not-allowed"
              >
                {otpTimer > 0 ? `Resend Code (${otpTimer}s)` : "Resend Code"}
              </button>

              <button
                type="button"
                onClick={() => {
                  setStep(1)
                  setOtpCode("")
                  setOtpTimer(0)
                  setError("")
                }}
                className="w-full py-3 text-primary font-medium hover:text-primary/80 transition-colors"
              >
                Back to Login
              </button>
            </motion.form>
          )}
        </AnimatePresence>

        <p className="text-center text-muted-foreground mt-6">
          Don't have an account?{" "}
          <Link href="/sign-up" className="text-primary hover:text-primary/80 font-medium transition-colors">
            Sign Up
          </Link>
        </p>
      </motion.div>

      {/* Success Modal */}
      <AnimatePresence>
        {showSuccess && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-50"
          >
            <motion.div
              initial={{ scale: 0, y: -50 }}
              animate={{ scale: 1, y: 0 }}
              exit={{ scale: 0, y: 50 }}
              className="bg-card border border-primary/20 rounded-2xl p-8 text-center max-w-md mx-4"
            >
              <motion.div
                animate={{ scale: [1, 1.2, 1], rotate: [0, 360, 0] }}
                transition={{ duration: 0.6, repeat: Number.POSITIVE_INFINITY }}
                className="text-6xl mb-4"
              >
                🎉
              </motion.div>
              <h2 className="text-2xl font-bold text-primary mb-2">Login Successful!</h2>
              <p className="text-white mb-4">Welcome back to VOTY</p>
              <p className="text-muted-foreground">Redirecting you to your dashboard...</p>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </main>
  )
}
