"use client"

import { motion } from "framer-motion"
import { useState } from "react"
import { User, Award, TrendingUp } from "lucide-react"

export default function ProfilePage() {
  const [stats] = useState({
    videosWatched: 24,
    quizzesTaken: 8,
    totalPoints: 450,
    streak: 12,
  })

  return (
    <div className="container mx-auto px-4 py-8 max-w-7xl">
      {/* Header */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
        className="mb-12"
      >
        <div className="flex items-center gap-4 mb-8">
          <div className="w-16 h-16 bg-gradient-to-br from-gold to-primary rounded-full flex items-center justify-center">
            <User size={32} className="text-black" />
          </div>
          <div>
            <h1 className="text-4xl font-bold text-gold">ADEMONRIN</h1>
            <p className="text-muted-foreground">Premium Member • Joined Dec 2024</p>
          </div>
        </div>
      </motion.div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-12">
        {[
          { icon: TrendingUp, label: "Videos Watched", value: stats.videosWatched },
          { icon: Award, label: "Quizzes Taken", value: stats.quizzesTaken },
          { icon: User, label: "Total Points", value: stats.totalPoints },
          { icon: TrendingUp, label: "Current Streak", value: `${stats.streak} days` },
        ].map((stat, idx) => (
          <motion.div
            key={idx}
            className="bg-card border border-primary/30 rounded-xl p-6 text-center"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: idx * 0.1 }}
          >
            <stat.icon className="text-gold mx-auto mb-3" size={32} />
            <p className="text-muted-foreground text-sm mb-1">{stat.label}</p>
            <p className="text-2xl font-bold text-white">{stat.value}</p>
          </motion.div>
        ))}
      </div>

      {/* Profile Settings */}
      <motion.div
        className="bg-card border border-primary/30 rounded-xl p-8"
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.4 }}
      >
        <h2 className="text-2xl font-bold text-gold mb-6">Account Settings</h2>
        <div className="space-y-6">
          <div>
            <label className="text-sm text-muted-foreground mb-2 block">Email Address</label>
            <input
              type="email"
              value="ademonrin@example.com"
              readOnly
              className="w-full bg-background text-white p-3 rounded-lg border border-primary/30"
            />
          </div>
          <div>
            <label className="text-sm text-muted-foreground mb-2 block">Date of Birth</label>
            <input type="date" className="w-full bg-background text-white p-3 rounded-lg border border-primary/30" />
          </div>
          <motion.button
            className="bg-gold py-3 rounded-lg font-bold hover:bg-gold/90 transition w-full text-ring"
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
          >
            Update Profile
          </motion.button>
        </div>
      </motion.div>
    </div>
  )
}
